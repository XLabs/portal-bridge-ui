import { Chain, ChainContext, Network, routes, TokenId as TokenId, TransactionId, amount as sdkAmount } from '@wormhole-foundation/sdk';
import { Token } from '../../config/tokens';
type Amount = sdkAmount.Amount;
export declare class SDKv2Route {
    readonly rc: routes.RouteConstructor;
    IS_TOKEN_BRIDGE_ROUTE: boolean;
    constructor(rc: routes.RouteConstructor);
    get AUTOMATIC_DEPOSIT(): boolean;
    get NATIVE_GAS_DROPOFF_SUPPORTED(): boolean;
    getV2ChainContext<C extends Chain>(chain: C): Promise<{
        chain: C;
        context: ChainContext<Network, C>;
    }>;
    isRouteSupported(sourceToken: Token, destToken: Token, fromChain: Chain, toChain: Chain): Promise<boolean>;
    isSupportedChain(chain: Chain): boolean;
    supportedDestTokens(sourceToken: Token | undefined, fromChain?: Chain | undefined, toChain?: Chain | undefined): Promise<TokenId[]>;
    getQuote(amount: Amount, sourceToken: Token, destToken: Token, sourceChain: Chain, destChain: Chain, options?: routes.AutomaticTokenBridgeRoute.Options): Promise<[
        routes.Route<Network>,
        routes.QuoteResult<routes.Options>,
        routes.RouteTransferRequest<Network>
    ]>;
    createRequest(sourceToken: Token, destToken: Token, sourceChain: Chain, destChain: Chain): Promise<routes.RouteTransferRequest<Network>>;
    computeReceiveAmount(amountIn: Amount, sourceToken: Token, destToken: Token, fromChain: Chain | undefined, toChain: Chain | undefined, options?: routes.AutomaticTokenBridgeRoute.Options): Promise<Amount>;
    computeQuote(amountIn: Amount, sourceToken: Token, destToken: Token, fromChain: Chain, toChain: Chain, options?: routes.AutomaticTokenBridgeRoute.Options): Promise<routes.QuoteResult<routes.Options>>;
    send(sourceToken: Token, amount: Amount, fromChain: Chain, senderAddress: string, toChain: Chain, recipientAddress: string, destToken: Token, options?: routes.AutomaticTokenBridgeRoute.Options): Promise<[routes.Route<Network>, routes.Receipt]>;
    resumeIfManual(tx: TransactionId): Promise<routes.Receipt | null>;
    isIlliquidDestToken(token: Token, fromContext: ChainContext<Network, Chain>, toContext: ChainContext<Network, Chain>): Promise<boolean>;
}
export {};
//# sourceMappingURL=route.d.ts.map