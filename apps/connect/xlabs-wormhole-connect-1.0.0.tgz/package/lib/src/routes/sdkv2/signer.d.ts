import { Network, Chain, ChainContext, UnsignedTransaction, Signer, SignAndSendSigner, TxHash } from '@wormhole-foundation/sdk';
import { TransferWallet } from '../../utils/wallet';
export declare class SDKv2Signer<N extends Network, C extends Chain> implements SignAndSendSigner<N, C> {
    _chain: Chain;
    _chainContextV2: ChainContext<N, C>;
    _address: string;
    _options: any;
    _walletType: TransferWallet;
    constructor(chain: Chain, chainContextV2: ChainContext<N, C>, address: string, options: any, walletType: TransferWallet);
    static fromChain<N extends Network, C extends Chain>(chain: Chain, address: string, options: any, walletType: TransferWallet): Promise<SDKv2Signer<N, C>>;
    static fromPrivateKey<N extends Network, C extends Chain>(chain: Chain): Promise<Signer<N, C>>;
    signAndSend(txs: UnsignedTransaction<N, C>[]): Promise<TxHash[]>;
    chain(): C;
    address(): string;
}
//# sourceMappingURL=signer.d.ts.map