import { Token } from '../config/tokens';
import { Chain, routes, TransactionId, amount as sdkAmount, TokenId } from '@wormhole-foundation/sdk';
import { default as SDKv2Route } from './sdkv2';
import { NttRoute } from '@wormhole-foundation/sdk-route-ntt';
export interface TxInfo {
    route: string;
    receipt: routes.Receipt;
}
export type QuoteResult = routes.QuoteResult<routes.Options>;
type forEachCallback<T> = (name: string, route: SDKv2Route) => T;
export declare const DEFAULT_ROUTES: (typeof routes.AutomaticCCTPRoute | typeof routes.CCTPRoute | typeof routes.AutomaticTokenBridgeRoute | typeof routes.TokenBridgeRoute | typeof routes.AutomaticPorticoRoute | typeof routes.TBTCRoute)[];
export interface QuoteParams {
    sourceChain: Chain;
    sourceToken: Token;
    destChain: Chain;
    destToken: Token;
    amount: sdkAmount.Amount;
    nativeGas: number;
}
export default class RouteOperator {
    preference: string[];
    routes: Record<string, SDKv2Route>;
    quoteCache: QuoteCache;
    constructor(routesConfig?: routes.RouteConstructor<any>[]);
    get(name: string): SDKv2Route;
    forEach<T>(callback: forEachCallback<T>): Promise<T[]>;
    resumeFromTx(tx: TransactionId): Promise<TxInfo | null>;
    allSupportedChains(): Chain[];
    allSupportedDestTokens(sourceToken: Token | undefined, sourceChain: Chain, destChain: Chain): Promise<TokenId[]>;
    getQuotes(routes: string[], params: QuoteParams): Promise<routes.QuoteResult<routes.Options>[]>;
}
declare class QuoteCache {
    ttl: number;
    cache: Record<string, QuoteCacheEntry>;
    pending: Record<string, QuotePromiseHandlers[]>;
    constructor(ttl: number);
    quoteParamsKey(routeName: string, params: QuoteParams): string;
    get(routeName: string, params: QuoteParams): QuoteResult | null;
    fetch(routeName: string, params: QuoteParams, route: SDKv2Route): Promise<QuoteResult>;
}
interface QuotePromiseHandlers {
    resolve: (quote: QuoteResult) => void;
    reject: (err: Error) => void;
}
declare class QuoteCacheEntry {
    result: QuoteResult;
    timestamp: Date;
    constructor(result: QuoteResult);
    age(): number;
}
export declare const nttRoutes: (nc: NttRoute.Config) => routes.RouteConstructor[];
export {};
//# sourceMappingURL=operator.d.ts.map