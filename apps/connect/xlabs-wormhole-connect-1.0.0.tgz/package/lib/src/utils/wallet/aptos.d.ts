import { Wallet } from '@xlabs-libs/wallet-aggregator-core';
import { AptosWallet } from '@xlabs-libs/wallet-aggregator-aptos';
import { Network } from '@wormhole-foundation/sdk';
import { AptosUnsignedTransaction, AptosChains } from '@wormhole-foundation/sdk-aptos';
export declare function fetchOptions(): Record<string, AptosWallet>;
export declare function signAndSendTransaction(request: AptosUnsignedTransaction<Network, AptosChains>, wallet: Wallet | undefined): Promise<import('@xlabs-libs/wallet-aggregator-core').SendTransactionResult<import('@xlabs-libs/wallet-aggregator-aptos').AptosSubmitResult>>;
//# sourceMappingURL=aptos.d.ts.map