import { Wallet } from '@xlabs-libs/wallet-aggregator-core';
import { ConfirmOptions } from '@solana/web3.js';
import { SolanaWallet } from '@xlabs-libs/wallet-aggregator-solana';
import { SolanaUnsignedTransaction } from '@wormhole-foundation/sdk-solana';
import { Network } from '@wormhole-foundation/sdk';
export declare function fetchOptions(): {
    walletConnect?: SolanaWallet | undefined;
    bitget: SolanaWallet;
    clover: SolanaWallet;
    coin98: SolanaWallet;
    solong: SolanaWallet;
    torus: SolanaWallet;
    nightly: SolanaWallet;
};
export declare function signAndSendTransaction(request: SolanaUnsignedTransaction<Network>, wallet: Wallet | undefined, options?: ConfirmOptions): Promise<string>;
//# sourceMappingURL=solana.d.ts.map