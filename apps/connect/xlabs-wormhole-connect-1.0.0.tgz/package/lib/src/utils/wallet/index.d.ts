import { Context, ChainConfig } from '../../sdklegacy';
import { Wallet } from '@xlabs-libs/wallet-aggregator-core';
import { Dispatch } from 'redux';
import { Network, Chain, UnsignedTransaction } from '@wormhole-foundation/sdk';
export declare enum TransferWallet {
    SENDING = "sending",
    RECEIVING = "receiving"
}
export declare const walletAcceptedChains: (context: Context | undefined) => Chain[];
export declare const setWalletConnection: (type: TransferWallet, wallet: Wallet) => void;
export declare const connectWallet: (type: TransferWallet, chain: Chain, walletInfo: WalletData, dispatch: Dispatch<any>) => Promise<boolean>;
export declare const connectLastUsedWallet: (type: TransferWallet, chain: Chain, dispatch: Dispatch<any>) => Promise<void>;
export declare const useConnectToLastUsedWallet: () => void;
export declare const getWalletConnection: (type: TransferWallet) => Wallet<import('@xlabs-libs/wallet-aggregator-core').ChainId, any, any, any, any, any, any, any, any, any, any, any, any> | undefined;
export declare const swapWalletConnections: () => void;
export declare const registerWalletSigner: (chain: Chain, type: TransferWallet) => Promise<void>;
export declare const switchChain: (chainId: number | string, type: TransferWallet) => Promise<string | undefined>;
export declare const disconnect: (type: TransferWallet) => Promise<void>;
export declare const signAndSendTransaction: (chain: Chain, request: UnsignedTransaction<Network, Chain>, walletType: TransferWallet, options?: any) => Promise<string>;
export type WalletData = {
    name: string;
    type: Context;
    icon: string;
    isReady: boolean;
    wallet: Wallet;
};
export declare const getWalletOptions: (config: ChainConfig | undefined) => Promise<WalletData[]>;
//# sourceMappingURL=index.d.ts.map