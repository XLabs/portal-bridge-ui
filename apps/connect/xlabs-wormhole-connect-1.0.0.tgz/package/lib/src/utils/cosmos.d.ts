import { Chain } from '@wormhole-foundation/sdk';
export declare function isGatewayChain(chain: Chain): boolean;
//# sourceMappingURL=cosmos.d.ts.map