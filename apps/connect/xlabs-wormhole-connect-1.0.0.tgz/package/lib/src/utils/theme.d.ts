export declare function mixHsl(hsl1: [number, number, number], hsl2: [number, number, number], ratio: number): [number, number, number];
export declare function mixRgb(rgb1: [number, number, number], rgb2: [number, number, number], ratio: number): [number, number, number];
export declare function mixHex(color1: string, color2: string, ratio: number): string;
export declare function rgbToHsl(r: number, g: number, b: number): [number, number, number];
export declare function hslToRgb(h: number, s: number, l: number): [number, number, number];
export declare function rgbToHex(r: number, g: number, b: number): string;
export declare function hexToRgb(hex: string): [number, number, number];
export declare function hexToHsl(hex: string): [number, number, number];
export declare function hslToHex(h: number, s: number, l: number): string;
export declare function opacify(color: string, opacity: number): string;
//# sourceMappingURL=theme.d.ts.map