import { RelayerFee } from '../store/relay';
import { Chain, AttestedTransferReceipt, RedeemedTransferReceipt, DestinationQueuedTransferReceipt, CompletedTransferReceipt, Network, amount, routes } from '@wormhole-foundation/sdk';
import { TokenTuple } from '../config/tokens';
export interface TransferInfo {
    sendTx: string;
    sender?: string;
    recipient: string;
    amount: amount.Amount;
    toChain: Chain;
    fromChain: Chain;
    tokenAddress: string;
    token: TokenTuple;
    tokenDecimals: number;
    receivedToken: TokenTuple;
    receiveAmount?: amount.Amount;
    relayerFee?: RelayerFee;
    receiveNativeAmount?: amount.Amount;
    eta?: number;
}
export type ExplorerInfo = {
    url: string;
    name: string;
    apiUrl: string;
};
export declare function getExplorerInfo(route: string | routes.Route<Network>, txHash: string): ExplorerInfo;
type ReceiptWithAttestation<AT> = AttestedTransferReceipt<AT> | RedeemedTransferReceipt<AT> | DestinationQueuedTransferReceipt<AT> | CompletedTransferReceipt<AT>;
export declare function parseReceipt(route: string, receipt: ReceiptWithAttestation<any>): Promise<TransferInfo | null>;
export declare const isMinAmountError: (error?: Error) => error is routes.MinAmountError;
export {};
//# sourceMappingURL=sdkv2.d.ts.map