import { TransferError, TransferDetails } from '../telemetry/types';
export declare const INSUFFICIENT_ALLOWANCE_REGEX: RegExp;
export declare const USER_REJECTED_REGEX: RegExp;
export declare const AMOUNT_IN_TOO_SMALL: RegExp;
export declare function interpretTransferError(e: any, transferDetails: TransferDetails): [string, TransferError];
export declare function maybeLogSdkError(e: any, prefix?: string): void;
//# sourceMappingURL=errors.d.ts.map