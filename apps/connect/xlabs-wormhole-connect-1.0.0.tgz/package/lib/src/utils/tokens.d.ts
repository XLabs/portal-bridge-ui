import { Wormhole, TokenId, Network } from '@wormhole-foundation/sdk';
interface TokenMetadataFromRpc {
    symbol: string;
    name: string;
    icon?: string;
}
export declare function getTokenMetadataFromRpc(tokenId: TokenId): Promise<TokenMetadataFromRpc | undefined>;
export declare function getTokenMetadataSolana(wh: Wormhole<Network>, tokenId: TokenId): Promise<TokenMetadataFromRpc | undefined>;
export declare function getTokenMetadataEvm(wh: Wormhole<Network>, tokenId: TokenId): Promise<TokenMetadataFromRpc | undefined>;
export {};
//# sourceMappingURL=tokens.d.ts.map