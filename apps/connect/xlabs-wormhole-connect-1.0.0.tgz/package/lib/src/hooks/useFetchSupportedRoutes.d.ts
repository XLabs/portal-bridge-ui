type HookReturn = {
    supportedRoutes: string[];
    isFetching: boolean;
};
declare const useFetchSupportedRoutes: () => HookReturn;
export default useFetchSupportedRoutes;
//# sourceMappingURL=useFetchSupportedRoutes.d.ts.map