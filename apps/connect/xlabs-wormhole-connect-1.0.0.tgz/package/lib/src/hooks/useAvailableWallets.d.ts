import { Context } from '../sdklegacy';
import { Chain } from '@wormhole-foundation/sdk';
import { WalletData } from '../utils/wallet';
type WalletOptions = {
    state: 'result' | 'loading' | 'error';
    options?: WalletData[];
    error?: string;
};
type Props = {
    chain: Chain | undefined;
    supportedChains: Set<Context>;
};
type ReturnProps = {
    walletOptionsResult: WalletOptions;
};
export declare const useAvailableWallets: (props: Props) => ReturnProps;
export {};
//# sourceMappingURL=useAvailableWallets.d.ts.map