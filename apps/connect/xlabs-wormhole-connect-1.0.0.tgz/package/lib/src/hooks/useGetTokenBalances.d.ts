import { Balances } from '../store/transferInput';
import { Token } from '../config/tokens';
import { Chain } from '@wormhole-foundation/sdk';
import { WalletData } from '../store/wallet';
declare const useGetTokenBalances: (wallet: WalletData | undefined, chain: Chain | undefined, tokens: Token[]) => {
    isFetching: boolean;
    balances: Balances;
};
export default useGetTokenBalances;
//# sourceMappingURL=useGetTokenBalances.d.ts.map