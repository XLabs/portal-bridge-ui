import { amount as sdkAmount, Chain } from '@wormhole-foundation/sdk';
import { QuoteResult } from '../routes/operator';
import { Token } from '../config/tokens';
type Params = {
    sourceChain?: Chain;
    sourceToken: Token | undefined;
    destChain?: Chain;
    destToken: Token | undefined;
    amount?: sdkAmount.Amount;
    nativeGas: number;
};
type HookReturn = {
    quotesMap: Record<string, QuoteResult | undefined>;
    isFetching: boolean;
};
declare const useRoutesQuotesBulk: (routes: string[], params: Params) => HookReturn;
export default useRoutesQuotesBulk;
//# sourceMappingURL=useRoutesQuotesBulk.d.ts.map