import { routes } from '@wormhole-foundation/sdk';
import { default as useRoutesQuotesBulk } from './useRoutesQuotesBulk';
type Quote = routes.Quote<routes.Options, routes.ValidatedTransferParams<routes.Options>>;
export type RouteWithQuote = {
    route: string;
    quote: Quote;
};
type HookReturn = {
    allSupportedRoutes: string[];
    sortedRoutes: string[];
    sortedRoutesWithQuotes: RouteWithQuote[];
    quotesMap: ReturnType<typeof useRoutesQuotesBulk>['quotesMap'];
    isFetching: boolean;
};
export declare const useSortedRoutesWithQuotes: () => HookReturn;
export {};
//# sourceMappingURL=useSortedRoutesWithQuotes.d.ts.map