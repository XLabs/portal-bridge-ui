import { Chain } from '@wormhole-foundation/sdk';
type Props = {
    destChain: Chain | undefined;
    destToken: string | undefined;
    route?: string;
    isTransactionInProgress: boolean;
};
export declare const useGasSlider: (props: Props) => {
    disabled: boolean;
    showGasSlider: boolean | undefined;
};
export {};
//# sourceMappingURL=useGasSlider.d.ts.map