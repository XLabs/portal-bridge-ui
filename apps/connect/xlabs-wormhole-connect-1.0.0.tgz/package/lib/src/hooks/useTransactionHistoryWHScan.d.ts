import { Transaction } from '../config/types';
type Props = {
    address: string;
    page?: number;
    pageSize?: number;
};
declare const useTransactionHistoryWHScan: (props: Props) => {
    transactions: Array<Transaction> | undefined;
    error: string;
    isFetching: boolean;
    hasMore: boolean;
};
export default useTransactionHistoryWHScan;
//# sourceMappingURL=useTransactionHistoryWHScan.d.ts.map