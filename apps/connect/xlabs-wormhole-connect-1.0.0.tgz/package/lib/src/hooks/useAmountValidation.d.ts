import { amount as sdkAmount } from '@wormhole-foundation/sdk';
import { QuoteResult } from '../routes/operator';
type HookReturn = {
    error?: string;
    warning?: string;
};
type Props = {
    balance?: sdkAmount.Amount | null;
    routes: string[];
    quotesMap: Record<string, QuoteResult | undefined>;
    tokenSymbol: string;
    isLoading: boolean;
    disabled?: boolean;
};
export declare const useAmountValidation: (props: Props) => HookReturn;
export {};
//# sourceMappingURL=useAmountValidation.d.ts.map