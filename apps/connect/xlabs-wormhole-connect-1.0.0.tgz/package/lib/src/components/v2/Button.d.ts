import { default as React } from 'react';
import { ButtonProps } from '@mui/material/Button';
type Props = Omit<ButtonProps, 'variant'> & {
    variant?: string;
};
/**
 * Custom Button component that extends MUI Button
 * @param variant:  Optional propoerty to specify the style variant of the button
 *                  Primary: The main CTA
 *
 */
declare const Button: React.ForwardRefExoticComponent<Omit<Props, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export default Button;
//# sourceMappingURL=Button.d.ts.map