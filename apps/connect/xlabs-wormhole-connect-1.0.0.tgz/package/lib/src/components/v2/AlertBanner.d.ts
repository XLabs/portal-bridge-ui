import { default as React, CSSProperties } from 'react';
type Props = {
    show: boolean;
    content: React.ReactNode | undefined;
    warning?: boolean;
    error?: boolean;
    style?: CSSProperties;
    testId?: string;
    color?: string;
    className?: string;
};
declare function AlertBanner(props: Props): React.JSX.Element;
export default AlertBanner;
//# sourceMappingURL=AlertBanner.d.ts.map