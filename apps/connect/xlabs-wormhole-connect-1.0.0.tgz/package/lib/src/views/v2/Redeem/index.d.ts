import { default as React } from 'react';
declare const Redeem: () => React.JSX.Element;
export default Redeem;
//# sourceMappingURL=index.d.ts.map