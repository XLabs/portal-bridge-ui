import { default as React } from 'react';
import { Chain } from '@wormhole-foundation/sdk';
import { ChainConfig } from '../../../../config/types';
import { WalletData } from '../../../../store/wallet';
import { Token } from '../../../../config/tokens';
type Props = {
    chain?: Chain | undefined;
    chainList: Array<ChainConfig>;
    token?: Token;
    sourceToken?: Token;
    tokenList?: Array<Token> | undefined;
    isFetching?: boolean;
    setToken: (value: Token) => void;
    setChain: (value: Chain) => void;
    wallet: WalletData;
    isSource: boolean;
    isTransactionInProgress: boolean;
    dataTestId?: string;
};
declare const AssetPicker: (props: Props) => React.JSX.Element;
export default AssetPicker;
//# sourceMappingURL=index.d.ts.map