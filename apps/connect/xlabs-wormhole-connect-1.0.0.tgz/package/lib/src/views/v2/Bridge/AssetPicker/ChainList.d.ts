import { default as React } from 'react';
import { ChainConfig } from '../../../../config/types';
import { WalletData } from '../../../../store/wallet';
import { Chain } from '@wormhole-foundation/sdk';
type Props = {
    chainList?: ChainConfig[];
    selectedChainConfig?: ChainConfig;
    showSearch: boolean;
    setShowSearch: (value: boolean) => void;
    wallet: WalletData;
    onChainSelect: (chain: Chain) => void;
};
declare const ChainList: (props: Props) => React.JSX.Element | null;
export default ChainList;
//# sourceMappingURL=ChainList.d.ts.map