import { default as React } from 'react';
/**
 * Bridge is the main component for Bridge view
 *
 */
declare const Bridge: () => React.JSX.Element;
export default Bridge;
//# sourceMappingURL=index.d.ts.map