import { default as React } from 'react';
import { Chain, amount as sdkAmount } from '@wormhole-foundation/sdk';
import { Token } from '../../../../config/tokens';
type Props = {
    sourceChain?: Chain;
    supportedSourceTokens: Array<Token>;
    tokenBalance: sdkAmount.Amount | null;
    isFetchingTokenBalance: boolean;
    error?: string;
    warning?: string;
};
/**
 * Renders the input control to set the transaction amount
 */
declare const AmountInput: (props: Props) => React.JSX.Element;
export default AmountInput;
//# sourceMappingURL=index.d.ts.map