import { default as React } from 'react';
type SearchInputProps = {
    value: string;
    onChange: (newValue: string) => void;
    onPaste?: (newValue: string) => void;
    placeholder?: string;
};
export default function SearchInput(props: SearchInputProps): React.JSX.Element;
export {};
//# sourceMappingURL=SearchInput.d.ts.map