import { default as React } from 'react';
import { amount, routes } from '@wormhole-foundation/sdk';
type Props = {
    route: string;
    isSelected: boolean;
    error?: string;
    destinationGasDrop?: amount.Amount;
    isFastest?: boolean;
    isCheapest?: boolean;
    isOnlyChoice?: boolean;
    onSelect?: (route: string) => void;
    quote?: routes.Quote<routes.Options>;
};
declare const SingleRoute: (props: Props) => React.JSX.Element;
export default SingleRoute;
//# sourceMappingURL=SingleRoute.d.ts.map