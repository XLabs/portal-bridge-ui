import { default as React } from 'react';
import { ChainConfig } from '../../../../config/types';
import { Token } from '../../../../config/tokens';
import { WalletData } from '../../../../store/wallet';
type Props = {
    tokenList?: Array<Token>;
    isFetching?: boolean;
    selectedChainConfig: ChainConfig;
    selectedToken?: Token;
    sourceToken?: Token;
    wallet: WalletData;
    onSelectToken: (key: Token) => void;
    isSource: boolean;
};
declare const TokenList: (props: Props) => React.JSX.Element;
export default TokenList;
//# sourceMappingURL=TokenList.d.ts.map