import { default as React } from 'react';
declare const TxHistory: () => React.JSX.Element;
export default TxHistory;
//# sourceMappingURL=index.d.ts.map