import { default as React } from 'react';
import { routes } from '@wormhole-foundation/sdk';
type Props = {
    routes: string[];
    selectedRoute?: string;
    onRouteChange: (route: string) => void;
    quotes: Record<string, routes.QuoteResult<routes.Options> | undefined>;
    isLoading: boolean;
};
declare const Routes: ({ ...props }: Props) => React.JSX.Element;
export default Routes;
//# sourceMappingURL=index.d.ts.map