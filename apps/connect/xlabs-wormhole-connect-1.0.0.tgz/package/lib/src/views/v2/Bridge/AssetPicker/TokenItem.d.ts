import { default as React } from 'react';
import { amount as sdkAmount, Chain } from '@wormhole-foundation/sdk';
import { Token } from '../../../../config/tokens';
type TokenItemProps = {
    token: Token;
    chain: Chain;
    balance: sdkAmount.Amount | null;
    price: string | null;
    onClick: () => void;
    disabled?: boolean;
    isSelected?: boolean;
    isFetchingBalance?: boolean;
};
declare function TokenItem(props: TokenItemProps): React.JSX.Element;
declare const _default: React.MemoExoticComponent<typeof TokenItem>;
export default _default;
//# sourceMappingURL=TokenItem.d.ts.map