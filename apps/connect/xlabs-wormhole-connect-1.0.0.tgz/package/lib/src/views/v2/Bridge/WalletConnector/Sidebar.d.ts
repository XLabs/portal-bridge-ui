import { default as React } from 'react';
import { TransferWallet } from '../../../../utils/wallet';
type Props = {
    type: TransferWallet;
    open: boolean;
    onClose?: () => any;
    showAddressInput?: boolean;
};
declare const WalletSidebar: (props: Props) => React.JSX.Element;
export default WalletSidebar;
//# sourceMappingURL=Sidebar.d.ts.map