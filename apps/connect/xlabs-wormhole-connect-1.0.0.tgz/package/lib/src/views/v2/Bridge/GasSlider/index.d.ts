import { default as React } from 'react';
import { amount } from '@wormhole-foundation/sdk';
declare const GasSlider: (props: {
    destinationGasDrop: amount.Amount;
    disabled: boolean;
}) => React.JSX.Element;
export default GasSlider;
//# sourceMappingURL=index.d.ts.map