import { default as React } from 'react';
import { ExplorerConfig } from '../../../../config/ui';
type ExplorerLinkProps = {
    address: string;
} & ExplorerConfig;
declare const ExplorerLink: (props: ExplorerLinkProps) => React.JSX.Element;
export default ExplorerLink;
//# sourceMappingURL=ExplorerLink.d.ts.map