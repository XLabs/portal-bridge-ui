import { default as React } from 'react';
declare function SwapInputs(): React.JSX.Element;
export default SwapInputs;
//# sourceMappingURL=index.d.ts.map