import { Chain } from '@wormhole-foundation/sdk';
import { Alignment } from '../components/Header';
export type UiConfig = {
    title?: string;
    cta?: {
        text: string;
        link: string;
    };
    explorer?: ExplorerConfig;
    defaultInputs?: DefaultInputs;
    pageHeader?: string | PageHeader;
    menu?: MenuEntry[];
    searchTx?: SearchTxConfig;
    partnerLogo?: string;
    walletConnectProjectId?: string;
    previewMode?: boolean;
    getHelpUrl?: string;
    showInProgressWidget?: boolean;
    disableUserInputtedTokens?: boolean;
    testOptions?: TestOptions;
    experimental?: Experimental;
};
export type TestOptions = {
    enableHeadlessSigner?: boolean;
};
export type Experiments = '';
export type Experimental = {
    [Experiment in Experiments]?: boolean;
};
export interface DefaultInputs {
    fromChain?: Chain;
    toChain?: Chain;
    fromToken?: string;
    toToken?: string;
    requiredChain?: Chain;
    preferredRouteName?: string;
}
export type ExplorerConfig = {
    href: string;
    label?: string;
    target?: '_blank' | '_self';
};
export type PageHeader = {
    text: string;
    align: Alignment;
};
export type SearchTxConfig = {
    txHash?: string;
    chainName?: string;
};
export interface MenuEntry {
    label: string;
    href: string;
    target?: string;
    order?: number;
}
export declare function createUiConfig(customConfig: UiConfig): UiConfig;
//# sourceMappingURL=ui.d.ts.map