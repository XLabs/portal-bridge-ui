import { WormholeConnectEventHandler, TriggerEventHandler } from '../telemetry/types';
export declare function wrapEventHandler(integrationHandler?: WormholeConnectEventHandler): TriggerEventHandler;
//# sourceMappingURL=events.d.ts.map