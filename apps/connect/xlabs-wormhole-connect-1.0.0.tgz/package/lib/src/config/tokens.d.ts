import { Chain, TokenId, TokenAddress, Network } from '@wormhole-foundation/sdk';
import { TokenIcon, TokenConfig, WrappedTokenAddresses } from './types';
export declare class Token {
    chain: Chain;
    address: TokenAddress<Chain>;
    decimals: number;
    symbol: string;
    name?: string;
    icon?: TokenIcon | string;
    tokenBridgeOriginalTokenId?: TokenId;
    constructor(chain: Chain, address: string, decimals: number, symbol: string, name?: string, icon?: TokenIcon | string, tokenBridgeOriginalTokenId?: TokenId);
    get display(): string;
    get shortAddress(): string;
    get tuple(): TokenTuple;
    get key(): string;
    get tokenId(): TokenId;
    get isNativeGasToken(): boolean;
    get isTokenBridgeWrappedToken(): boolean;
    get nativeChain(): "Ethereum" | "Terra" | "Solana" | "Algorand" | "Near" | "Aptos" | "Sui" | "Bsc" | "Polygon" | "Avalanche" | "Oasis" | "Aurora" | "Fantom" | "Karura" | "Acala" | "Klaytn" | "Celo" | "Moonbeam" | "Neon" | "Terra2" | "Injective" | "Osmosis" | "Arbitrum" | "Optimism" | "Gnosis" | "Pythnet" | "Xpla" | "Btc" | "Base" | "Sei" | "Scroll" | "Mantle" | "Blast" | "Xlayer" | "Linea" | "Berachain" | "Seievm" | "Snaxchain" | "Unichain" | "Worldchain" | "Ink" | "HyperEVM" | "Monad" | "Mezo" | "Wormchain" | "Cosmoshub" | "Evmos" | "Kujira" | "Neutron" | "Celestia" | "Stargaze" | "Seda" | "Dymension" | "Provenance" | "Noble" | "Sepolia" | "ArbitrumSepolia" | "BaseSepolia" | "OptimismSepolia" | "Holesky" | "PolygonSepolia";
    equals(other: Token): boolean;
    toJson(): TokenJson;
    static fromJson({ chain, address, decimals, symbol, name, icon, tokenBridgeOriginalTokenId, }: TokenJson): Token;
}
interface TokenJson {
    chain: string;
    address: string;
    decimals: number;
    symbol: string;
    name: string;
    icon: string;
    tokenBridgeOriginalTokenId: TokenTuple | undefined;
}
export declare class TokenMapping<T> {
    lastUpdate: Date;
    _localStorageKey?: string;
    _mapping: Map<Chain, Map<string, T>>;
    size: number;
    constructor();
    add(token: TokenId, value: T): void;
    get(key: string): T | undefined;
    get(tokenId: TokenId): T | undefined;
    get(tokenTuple: TokenTuple): T | undefined;
    get(chain: Chain, address: string): T | undefined;
    mustGet(key: string): T;
    mustGet(tokenId: TokenId): T;
    mustGet(tokenTuple: TokenTuple): T;
    mustGet(chain: Chain, address: string): T;
    getList(keys: string[]): Token[];
    getList(keys: TokenId[]): Token[];
    getList(keys: TokenTuple[]): Token[];
    getAllForChain(chain: Chain): T[];
    getAll(): T[];
    getAllTokenIds(): TokenId[];
    get chains(): Chain[];
    merge(other: TokenMapping<T>): void;
    clear(): void;
    forEach(callback: (tokenId: TokenId, val: T) => void): void;
    get empty(): boolean;
}
export declare class TokenCache extends TokenMapping<Token> {
    add(token: Token): void;
    getGasToken(chain: Chain): Token | undefined;
    findByAddressOrSymbol(chain: Chain, addressOrSymbol: string): Token | undefined;
    findBySymbol(chain: Chain, symbol: string): Token | undefined;
    setLocalStorageKey(key: string): void;
    addFromTokenId(tokenId: TokenId): Promise<Token>;
    persist(): void;
    static load(localStorageKey: string): TokenCache;
}
export declare function buildTokenCache(network: Network, tokens: TokenConfig[], wrappedTokens: WrappedTokenAddresses, tokenFilter?: string[]): TokenCache;
export type TokenTuple = [Chain, string];
export declare function isTokenTuple(thing: any): thing is TokenTuple;
export declare function tokenIdToTuple(tokenId: TokenId): TokenTuple;
export declare function tokenIdFromTuple(tokenTuple: TokenTuple): TokenId;
export declare function tokenKey(tokenId: TokenId): string;
export declare function parseTokenKey(key: string): TokenId;
export {};
//# sourceMappingURL=tokens.d.ts.map