import { ChainConfig as BaseChainConfig, ChainResourceMap, WormholeContext, WormholeConfig } from '../sdklegacy';
import { Network, Wormhole as WormholeV2, Chain, AttestationReceipt, routes } from '@wormhole-foundation/sdk';
import { PriorityFeeOptions } from '@wormhole-foundation/sdk-solana';
import { TransferDetails, TriggerEventHandler, WormholeConnectEventHandler } from '../telemetry/types';
import { default as RouteOperator } from '../routes/operator';
import { UiConfig } from './ui';
import { TransferInfo } from '../utils/sdkv2';
import { Token, TokenCache, TokenTuple } from './tokens';
export declare enum TokenIcon {
    'AVAX' = 1,
    'BNB' = 2,
    'BSC' = 3,
    'CELO' = 4,
    'ETH' = 5,
    'FANTOM' = 6,
    'POLYGON' = 7,
    'SOLANA' = 8,
    'USDC' = 9,
    'GLMR' = 10,
    'DAI' = 11,
    'USDT' = 12,
    'BUSD' = 13,
    'WBTC' = 14,
    'SUI' = 15,
    'APT' = 16,
    'SEI' = 17,
    'BASE' = 18,
    'OSMO' = 19,
    'TBTC' = 20,
    'WSTETH' = 21,
    'ARBITRUM' = 22,
    'OPTIMISM' = 23,
    'ATOM' = 24,
    'EVMOS' = 25,
    'KUJI' = 26,
    'PYTH' = 27,
    'INJ' = 28,
    'KLAY' = 29,
    'NTT' = 30,
    'SCROLL' = 31,
    'BLAST' = 32,
    'XLAYER' = 33,
    'MANTLE' = 34,
    'WORLDCHAIN' = 35,
    'BERA' = 36
}
export type TransferSide = 'source' | 'destination';
export interface ExtendedTransferDetails extends TransferDetails {
    fromWalletAddress: string;
    toWalletAddress: string;
}
export interface ValidateTransferResult {
    isValid: boolean;
    error?: string;
}
export type ValidateTransferHandler = (transferDetails: ExtendedTransferDetails) => Promise<ValidateTransferResult>;
export type IsRouteSupportedHandler = (transferDetails: TransferDetails) => Promise<boolean>;
export type IsTokenSupportedHandler = (token: Token) => boolean;
export interface WormholeConnectConfig {
    network?: Network;
    rpcs?: ChainResourceMap;
    coingecko?: {
        apiKey?: string;
        customUrl?: string;
    };
    chains?: Chain[];
    tokens?: (string | TokenTuple)[];
    routes?: routes.RouteConstructor<any>[];
    tokensConfig?: TokensConfig;
    wrappedTokens?: WrappedTokenAddresses;
    eventHandler?: WormholeConnectEventHandler;
    validateTransferHandler?: ValidateTransferHandler;
    isRouteSupportedHandler?: IsRouteSupportedHandler;
    isTokenSupportedHandler?: IsTokenSupportedHandler;
    ui?: UiConfig;
    transactionSettings?: TransactionSettings;
}
export interface InternalConfig<N extends Network> {
    network: N;
    _v2Wormhole?: WormholeV2<N>;
    whLegacy: WormholeContext;
    sdkConfig: WormholeConfig;
    isMainnet: boolean;
    rpcs: ChainResourceMap;
    mayanApi: string;
    wormholeApi: string;
    wormholeRpcHosts: string[];
    coingecko?: {
        apiKey?: string;
        customUrl?: string;
    };
    tokens: TokenCache;
    tokenWhitelist?: (string | TokenTuple)[];
    chains: ChainsConfig;
    chainsArr: ChainConfig[];
    routes: RouteOperator;
    triggerEvent: TriggerEventHandler;
    validateTransfer?: ValidateTransferHandler;
    isRouteSupportedHandler?: IsRouteSupportedHandler;
    isTokenSupportedHandler?: IsTokenSupportedHandler;
    ui: UiConfig;
    guardianSet: GuardianSetData;
    transactionSettings: TransactionSettings;
}
export type TokenConfig = {
    symbol: string;
    name?: string;
    decimals: number;
    icon: TokenIcon | string;
    tokenId: {
        chain: Chain;
        address: string;
    };
};
export type TokensConfig = {
    [key: string]: TokenConfig;
};
export interface ChainConfig extends BaseChainConfig {
    sdkName: Chain;
    displayName: string;
    explorerUrl: string;
    explorerName: string;
    wrappedGasToken?: string;
    chainId: number | string;
    icon: Chain;
    symbol?: string;
}
export type ChainsConfig = {
    [chain in Chain]?: ChainConfig;
};
export type RpcMapping = {
    [chain in Chain]?: string;
};
export type GuardianSetData = {
    index: number;
    keys: string[];
};
export type NetworkData = {
    chains: ChainsConfig;
    tokens: TokenConfig[];
    wrappedTokens: WrappedTokenAddresses;
    rpcs: RpcMapping;
    guardianSet: GuardianSetData;
};
export type WrappedTokenAddresses = {
    [chain in Chain]?: {
        [address: string]: {
            [otherChain in Chain]?: string;
        };
    };
};
export interface Transaction {
    txHash: string;
    sender?: string;
    recipient: string;
    amount?: string;
    amountUsd?: number;
    receiveAmount?: string;
    fromChain: Chain;
    fromToken?: Token;
    toChain: Chain;
    toToken?: Token;
    senderTimestamp: string;
    receiverTimestamp?: string;
    explorerLink: string;
    inProgress: boolean;
}
export interface TransactionLocal {
    receipt: routes.Receipt<AttestationReceipt>;
    route: string;
    timestamp: number;
    txHash: string;
    txDetails: TransferInfo;
    isReadyToClaim?: boolean;
}
export interface TransactionSettings {
    Solana?: {
        priorityFee?: PriorityFeeOptions;
    };
}
//# sourceMappingURL=types.d.ts.map