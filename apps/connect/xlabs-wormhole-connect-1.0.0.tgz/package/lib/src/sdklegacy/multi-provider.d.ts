import * as ethers from 'ethers';
type Provider = ethers.Provider;
/**
 * The MultiProvider manages a collection of [Domains]{@link Domain} and allows
 * developers to enroll ethers Providers and Signers for each domain. It is
 * intended to enable faster multi-chain development by housing all chain
 * connections under a single roof.
 *
 * Generally, we intend developers inherit the MultiProvider. Which is to say,
 * the expected usage pattern is `class AppContext<T> extends MultiProvider<T>`.
 * This way, the `MultiProvider` registration methods are available on the app
 * context.
 *
 * However, the multiprovider also works well as a property on a `Context`
 * class.  E.g. `class AppContext<T> { protected provider: MultiProvider<T> }`
 *
 * The `Domain` type parameter to the MultiProvider specifies an internal data
 * carrier that describes chains. This can be as simple as a name and a number.
 * This is the logical place to insert app-specific chain information. E.g. if
 * your application needs to know the blocktime of a chain, it should be on the
 * `Domain` type.
 *
 * @example
 * import { MultiProvider, Domain } from '@nomad-xyz/multi-provider';
 * const myApp = new MultiProvider<Domain>();
 * myApp.registerDomain({name: 'Polygon', id: 50});
 * myApp.registerDomain({name: 'Ethereum', id: 1});
 * myApp.registerRpcProvider('Celo', 'https://forno.celo.org');
 * myApp.registerRpcProvider('Ethereum', '...');
 * myApp.registerSigner('Ethereum', someSigner);
 * myApp.registerSigner('Polygon', someSigner);
 */
export declare class MultiProvider<T extends Domain> {
    protected domains: Map<string, T>;
    protected providers: Map<string, Provider>;
    protected signers: Map<string, ethers.Signer>;
    constructor();
    /**
     * Resgister a domain with the MultiProvider. This allows the multiprovider
     * to resolves tha domain info, and reference it by name or number.
     *
     * @param domain The Domain object to register.
     */
    registerDomain(domain: T): void;
    get registeredDomains(): Array<Readonly<T>>;
    get domainNumbers(): number[];
    get domainNames(): string[];
    get missingProviders(): string[];
    /**
     * Resolve a domain name (or number) to the canonical number.
     *
     * This function is used extensively to disambiguate domains.
     *
     * @param nameOrDomain A domain name or number.
     * @returns The canonical domain number.
     */
    resolveDomain(nameOrDomain: string | number): number;
    /**
     * Resolve the name of a registered {@link Domain}, from its name or number.
     *
     * Similar to `resolveDomain`.
     *
     * @param nameOrDomain A domain name or number.
     * @returns The name
     * @throws If the domain is unknown
     */
    resolveDomainName(nameOrDomain: string | number): string;
    /**
     * Check whether the {@link MultiProvider} is aware of a domain.
     *
     * @param nameOrDomain A domain name or number.
     * @returns true if the {@link Domain} has been registered, else false.
     */
    knownDomain(nameOrDomain: string | number): boolean;
    /**
     * Get the registered {@link Domain} object (if any)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A {@link Domain} (if the domain has been registered)
     */
    getDomain(nameOrDomain: number | string): T | undefined;
    /**
     * Get the registered {@link Domain} object (or error)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A {@link Domain}
     * @throws if the domain has not been registered
     */
    mustGetDomain(nameOrDomain: number | string): T;
    /**
     * Register an ethers Provider for a specified domain.
     *
     * @param nameOrDomain A domain name or number.
     * @param provider An ethers Provider to be used by requests to that domain.
     */
    registerProvider(nameOrDomain: string | number, provider: Provider): void;
    /**
     * Shortcut to register a provider by its HTTP RPC URL.
     *
     * @param nameOrDomain A domain name or number.
     * @param rpc The HTTP RPC Url
     */
    registerRpcProvider(nameOrDomain: string | number, rpc: string): void;
    /**
     * Get the Provider associated with a doman (if any)
     *
     * @param nameOrDomain A domain name or number.
     * @returns The currently registered Provider (or none)
     */
    getProvider(nameOrDomain: string | number): Provider | undefined;
    /**
     * Get the Provider associated with a doman (or error)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A Provider
     * @throws If no provider has been registered for the specified domain
     */
    mustGetProvider(nameOrDomain: string | number): Provider;
    /**
     * Register an ethers Signer for a specified domain.
     *
     * @param nameOrDomain A domain name or number.
     * @param signer An ethers Signer to be used by requests to that domain.
     */
    registerSigner(nameOrDomain: string | number, signer: ethers.Signer): void;
    /**
     * Remove the registered ethers Signer from a domain. This function will
     * attempt to preserve any Provider that was previously connected to this
     * domain.
     *
     * @param nameOrDomain A domain name or number.
     */
    unregisterSigner(nameOrDomain: string | number): void;
    /**
     * Clear all signers from all registered domains.
     */
    clearSigners(): void;
    /**
     * A shortcut for registering a basic local privkey signer on a domain.
     *
     * @param nameOrDomain A domain name or number.
     * @param privkey A private key string passed to `ethers.Wallet`
     */
    registerWalletSigner(nameOrDomain: string | number, privkey: string): void;
    /**
     * Return the signer registered to a domain (if any).
     *
     * @param nameOrDomain A domain name or number.
     * @returns The registered signer (or undefined)
     */
    getSigner(nameOrDomain: string | number): ethers.Signer | undefined;
    /**
     * Get the Signer associated with a doman (or error)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A Signer
     * @throws If no provider has been registered for the specified domain
     */
    mustGetSigner(nameOrDomain: string | number): ethers.Signer;
    /**
     * Returns the most privileged connection registered to a domain. E.g.
     * this function will attempt to return a Signer, then attempt to return the
     * Provider (if no Signer is registered). If neither Signer nor Provider is
     * registered for a domain, it will return undefined
     *
     * @param nameOrDomain A domain name or number.
     * @returns A Signer (if any), otherwise a Provider (if any), otherwise
     *          undefined
     */
    getConnection(nameOrDomain: string | number): ethers.Signer | ethers.Provider | undefined;
    /**
     * Get the Connection associated with a doman (or error)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A Signer
     * @returns A Signer (if any), otherwise a Provider (if any), otherwise error
     */
    mustGetConnection(nameOrDomain: string | number): ethers.Signer | ethers.Provider;
    /**
     * Resolves the address of a Signer on a domain (or undefined, if no Signer)
     *
     * @param nameOrDomain A domain name or number.
     * @returns A Promise for the address of the registered signer (if any)
     */
    getAddress(nameOrDomain: string | number): Promise<string | undefined>;
}
/**
 * Unreachable error. Useful for type narrowing.
 */
export declare class UnreachableError extends Error {
    constructor(extra?: string);
}
/**
 * An error containing a multi-provider-based context
 */
export declare abstract class WithContext<D extends Domain, T extends MultiProvider<D>> extends Error {
    provider: T;
    constructor(provider: T, msg: string);
}
/**
 * Thrown when attempting to access a domain not registered on the context
 */
export declare class UnknownDomainError<D extends Domain, T extends MultiProvider<D>> extends WithContext<D, T> {
    domain: string | number;
    constructor(provider: T, domain: string | number);
}
/**
 * Thrown when attempting to access contract data on a domain with no
 * registered provider
 */
export declare class NoProviderError<D extends Domain, T extends MultiProvider<D>> extends WithContext<D, T> {
    domain: string | number;
    domainName: string;
    domainNumber: number;
    constructor(provider: T, domain: string | number);
}
export interface Domain {
    name: string;
    domain: number;
}
export {};
//# sourceMappingURL=multi-provider.d.ts.map