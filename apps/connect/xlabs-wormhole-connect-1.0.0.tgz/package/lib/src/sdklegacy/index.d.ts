export * from './types';
export * from './config/MAINNET';
export * from './wormhole';
export * from './utils';
export * from './errors';
export declare const CONFIG: {
    MAINNET: import('./types').WormholeConfig;
    TESTNET: import('./types').WormholeConfig;
    DEVNET: import('./types').WormholeConfig;
};
//# sourceMappingURL=index.d.ts.map