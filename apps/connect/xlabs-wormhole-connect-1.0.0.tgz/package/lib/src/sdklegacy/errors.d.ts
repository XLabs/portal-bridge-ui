export declare class TokenNotSupportedForRelayError extends Error {
    static MESSAGE: string;
    constructor();
}
export declare class TokenNotRegisteredError extends Error {
    static MESSAGE: string;
    constructor();
}
export declare class InsufficientFundsForGasError extends Error {
    static MESSAGE: string;
    static MESSAGE_REGEX: RegExp;
    constructor();
}
//# sourceMappingURL=errors.d.ts.map