export declare const store: import('@reduxjs/toolkit').EnhancedStore<{
    redeem: import('./redeem').RedeemState;
    transferInput: import('./transferInput').TransferInputState;
    router: import('./router').RouterState;
    wallet: import('./wallet').WalletState;
    relay: import('./relay').RelayState;
}, import('redux').UnknownAction, import('@reduxjs/toolkit').Tuple<[import('redux').StoreEnhancer<{
    dispatch: import('redux-thunk').ThunkDispatch<{
        redeem: import('./redeem').RedeemState;
        transferInput: import('./transferInput').TransferInputState;
        router: import('./router').RouterState;
        wallet: import('./wallet').WalletState;
        relay: import('./relay').RelayState;
    }, undefined, import('redux').UnknownAction>;
}>, import('redux').StoreEnhancer]>>;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
//# sourceMappingURL=index.d.ts.map