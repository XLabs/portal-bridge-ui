import { PayloadAction } from '@reduxjs/toolkit';
import { Chain, amount } from '@wormhole-foundation/sdk';
export type Balance = {
    amount: amount.Amount;
};
export type Balances = {
    tokens: Record<string, Balance>;
    lastUpdated: Date;
};
export type Wallet = string;
type ChainBalances = Partial<Record<Chain, Record<Wallet, Balances>>>;
export interface BalancesState {
    balances: ChainBalances;
}
export declare const transferInputSlice: import('@reduxjs/toolkit').Slice<BalancesState, {
    setBalances: (state: BalancesState, { payload: { chain, wallet, balances }, }: PayloadAction<{
        chain: Chain;
        wallet: Wallet;
        balances: Balances;
    }>) => void;
}, "balances", "balances", import('@reduxjs/toolkit').SliceSelectors<BalancesState>>;
export {};
//# sourceMappingURL=balances.d.ts.map