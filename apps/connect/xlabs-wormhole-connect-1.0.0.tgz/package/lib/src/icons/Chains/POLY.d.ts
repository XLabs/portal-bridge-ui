import { default as React } from 'react';
declare function MATIC(): React.JSX.Element;
export default MATIC;
//# sourceMappingURL=POLY.d.ts.map