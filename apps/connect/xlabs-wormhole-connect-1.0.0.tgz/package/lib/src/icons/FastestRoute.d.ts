declare const _default: import('@mui/material/OverridableComponent').OverridableComponent<import('@mui/material').SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default _default;
//# sourceMappingURL=FastestRoute.d.ts.map