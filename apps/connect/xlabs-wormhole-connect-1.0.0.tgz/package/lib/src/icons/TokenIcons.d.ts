import { default as React } from 'react';
import { TokenIcon } from '../config/types';
type Props = {
    icon?: TokenIcon | string;
    height?: number;
};
declare function TokenIconComponent(props: Props): React.JSX.Element;
export default TokenIconComponent;
//# sourceMappingURL=TokenIcons.d.ts.map