import { PaletteMode, Theme } from '@mui/material';
export type WormholeConnectTheme = {
    mode: PaletteMode;
    background?: PaletteMode;
    input?: string;
    inputFillTreatment?: boolean;
    primary?: string;
    secondary?: string;
    text?: string;
    textSecondary?: string;
    error?: string;
    success?: string;
    font?: string;
};
type Color = {
    main: string;
};
export type InternalTheme = {
    mode: PaletteMode;
    primary: Color;
    secondary: Color;
    divider: string;
    background: {
        default: string;
    };
    text: {
        primary: string;
        secondary: string;
    };
    error: Color;
    info: Color;
    success: Color;
    warning: Color;
    button: {
        primary: string;
        primaryText: string;
        disabled: string;
        disabledText: string;
        action: string;
        actionText: string;
        hover: string;
    };
    options: {
        hover: string;
        select: string;
    };
    card: {
        background: string;
        elevation: string;
        secondary: string;
    };
    popover: {
        background: string;
        elevation: string;
        secondary: string;
    };
    input: {
        background: string;
        border: string;
        fillTreatment: boolean;
    };
    font: string;
    logo: string;
};
export declare const light: InternalTheme;
export declare const dark: InternalTheme;
export declare const generateTheme: (customTheme: WormholeConnectTheme) => Theme;
export {};
//# sourceMappingURL=theme.d.ts.map