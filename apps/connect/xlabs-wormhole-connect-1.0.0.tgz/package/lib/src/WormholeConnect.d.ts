import { WormholeConnectConfig } from './config/types';
import { WormholeConnectTheme } from 'theme';
import * as React from 'react';
export interface WormholeConnectProps {
    theme?: WormholeConnectTheme;
    config?: WormholeConnectConfig;
}
export default function WormholeConnect({ config, theme, }: WormholeConnectProps): React.JSX.Element;
//# sourceMappingURL=WormholeConnect.d.ts.map