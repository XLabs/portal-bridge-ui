import { default as WormholeConnect } from './WormholeConnect';
import { WormholeConnectTheme } from './theme';
import { default as MAINNET } from './config/mainnet';
import { default as TESTNET } from './config/testnet';
import { buildConfig } from './config';
import { WormholeConnectConfig } from './config/types';
import { DEFAULT_ROUTES, nttRoutes } from './routes/operator';
import { routes, Chain } from '@wormhole-foundation/sdk';
import { MayanRoute, MayanRouteWH, MayanRouteMCTP, MayanRouteSWIFT, MayanRouteSHUTTLE } from '@mayanfinance/wormhole-sdk-route';
import { nttAutomaticRoute, nttManualRoute } from '@wormhole-foundation/sdk-route-ntt';
import { M0AutomaticRoute } from '@m0-foundation/ntt-sdk-route';
import { wormholeConnectHosted, HostedParameters } from './hosted';
import { Token } from './config/tokens';
declare const AutomaticTokenBridgeRoute: typeof routes.AutomaticTokenBridgeRoute, TokenBridgeRoute: typeof routes.TokenBridgeRoute, AutomaticCCTPRoute: typeof routes.AutomaticCCTPRoute, CCTPRoute: typeof routes.CCTPRoute, AutomaticPorticoRoute: typeof routes.AutomaticPorticoRoute;
export default WormholeConnect;
export { MAINNET, TESTNET, buildConfig, WormholeConnectConfig, Chain, WormholeConnectTheme, Token, DEFAULT_ROUTES, nttRoutes, nttAutomaticRoute, nttManualRoute, AutomaticTokenBridgeRoute, TokenBridgeRoute, AutomaticCCTPRoute, CCTPRoute, AutomaticPorticoRoute, MayanRoute, MayanRouteWH, MayanRouteMCTP, MayanRouteSWIFT, MayanRouteSHUTTLE, M0AutomaticRoute, wormholeConnectHosted, HostedParameters, };
export * from './telemetry';
//# sourceMappingURL=index.d.ts.map